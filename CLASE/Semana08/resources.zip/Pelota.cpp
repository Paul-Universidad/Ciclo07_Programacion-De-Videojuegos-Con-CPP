#include "Pelota.h"
#include <stdlib.h> 

Pelota::Pelota() : pos_x( rand() % 251)
                 , pos_y( rand() % 251)
                 , radio(40)
                 , vel_x(7)
                 , vel_y(2) 
                 , color_pelota( al_map_rgb( rand() % 254
                                           , rand() % 254
                                           , rand() % 254 ) ) {}

Pelota::~Pelota() {}

void Pelota::mover() {
    pos_x = pos_x + vel_x;
    pos_y = pos_y + vel_y;
}
void Pelota::rebote() {
    if( ( pos_y <= radio ) || ( pos_y >= 600-radio ) )
        vel_y = -vel_y;
    
    if ( ( pos_x <= radio ) || ( pos_x >= 800-radio ) )
        vel_x = -vel_x;
}

