#ifndef PELOTA_H
#define PELOTA_H

#include <allegro5/allegro.h>
#include <stdlib.h> 

class Pelota{
    private:
        double pos_x;
        double pos_y;
        int radio;
        double vel_x;
        double vel_y;
        ALLEGRO_COLOR color_pelota;

    public:
        Pelota();  // Constructor
        ~Pelota(); // Destructor

    void mover();
    void rebote();    
    double getX() { 
        return pos_x; }
    
    double getY()  { 
        return pos_y; }

    int getRadio() { 
        return radio; }

    ALLEGRO_COLOR getColor()  { 
        return color_pelota; }

};

#endif
